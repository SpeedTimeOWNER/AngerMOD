document.addEventListener('DOMContentLoaded', () => {
    const sendBtn = document.getElementById('send-btn');
    const input = document.getElementById('user-input');
    const chatBox = document.getElementById('chat-box');

    // Авто-скролл вниз при загрузке
    if(chatBox) chatBox.scrollTop = chatBox.scrollHeight;

    if(sendBtn) {
        sendBtn.addEventListener('click', sendMessage);
        input.addEventListener('keypress', (e) => { 
            if(e.key === 'Enter') sendMessage(); 
        });
    }

    async function sendMessage() {
        const text = input.value;
        if (!text) return;

        const model = document.getElementById('model-select').value;
        const deepThink = document.getElementById('deep-think').checked;

        // Удаляем "пустое состояние", если оно есть
        const emptyState = document.querySelector('.empty-state');
        if(emptyState) emptyState.remove();

        // 1. Показываем сообщение юзера сразу
        appendMessage('user', text);
        input.value = '';
        input.disabled = true; // Блокируем ввод пока думает

        // 2. Отправляем на сервер
        try {
            const response = await fetch('/api/chat', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({ prompt: text, model: model, deep_think: deepThink })
            });
            const data = await response.json();

            // 3. Показываем ответ
            if (data.error) {
                appendMessage('assistant error', data.error);
            } else if (data.is_image) {
                appendMessage('assistant', `<img src="${data.response}" class="generated-image">`, true);
            } else {
                appendMessage('assistant', data.response);
            }
        } catch (e) {
            appendMessage('assistant error', "Ошибка соединения с сервером.");
        }
        
        input.disabled = false;
        input.focus();
    }

    function appendMessage(role, content, isHtml=false) {
        const row = document.createElement('div');
        row.className = `message-row ${role.split(' ')[0]}`; // user или assistant
        
        const bubble = document.createElement('div');
        bubble.className = 'message-bubble';
        if (role.includes('error')) bubble.style.color = 'red';

        if (isHtml) bubble.innerHTML = content;
        else bubble.innerText = content;

        row.appendChild(bubble);
        chatBox.appendChild(row);
        chatBox.scrollTop = chatBox.scrollHeight;
    }
});
