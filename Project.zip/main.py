import os
import time
import datetime
import uuid
from flask import Flask, render_template, request, jsonify, redirect, url_for, flash, session
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from openai import OpenAI

# --- КОНФИГ ---
class Config:
    SECRET_KEY = 'anger-secret-key-final'
    SQLALCHEMY_DATABASE_URI = 'sqlite:///anger.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False

app = Flask(__name__)
app.config.from_object(Config)

db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = 'auth'

# --- API КЛЮЧ ---
client = OpenAI(api_key="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")

# --- МОДЕЛИ ---
MODEL_MAPPING = {
    "gpt-4o": "gpt-4o",
    "gpt-4o-mini": "gpt-4o-mini",
    "dalle-3": "dall-e-3"
}

# --- БАЗА ДАННЫХ ---
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)
    requests_count = db.Column(db.Integer, default=0)
    last_request_date = db.Column(db.String(20), default=str(datetime.date.today()))
    images_count = db.Column(db.Integer, default=0)
    last_image_time = db.Column(db.Float, default=0.0)

class ChatHistory(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    session_id = db.Column(db.String(50), nullable=False, default='default') # <--- НОВОЕ ПОЛЕ (ID ЧАТА)
    role = db.Column(db.String(20), nullable=False)
    content = db.Column(db.Text, nullable=False)
    is_image = db.Column(db.Boolean, default=False)
    timestamp = db.Column(db.DateTime, default=datetime.datetime.utcnow)

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# --- ЛИМИТЫ ---
def check_limits(user, is_gen_image=False):
    today = str(datetime.date.today())
    if user.last_request_date != today:
        user.requests_count = 0
        user.images_count = 0
        user.last_request_date = today
        db.session.commit()

    if user.requests_count >= 200: return False, "❌ Лимит исчерпан."
    if is_gen_image:
        if user.images_count >= 10: return False, "❌ Лимит фото!"
        if (time.time() - user.last_image_time) < 60: return False, "⏳ Жди минуту."
    return True, "OK"

# --- МАРШРУТЫ ---
with app.app_context():
    db.create_all()

@app.route('/')
@login_required
def index():
    # Если у юзера нет активной сессии - создаем новую
    if 'chat_id' not in session:
        session['chat_id'] = str(uuid.uuid4())

    # Загружаем сообщения ТОЛЬКО из текущего чата (Session ID)
    current_chat_id = session['chat_id']
    history = ChatHistory.query.filter_by(
        user_id=current_user.id, 
        session_id=current_chat_id
    ).order_by(ChatHistory.timestamp).all()

    return render_template('index.html', user=current_user, history=history)

# --- ЛОГИКА НОВОГО ЧАТА ---
@app.route('/new_chat')
@login_required
def new_chat():
    # Генерируем новый уникальный ID для чата
    session['chat_id'] = str(uuid.uuid4())
    # Перезагружаем страницу - она будет пустой
    return redirect(url_for('index'))

@app.route('/auth')
def auth():
    if current_user.is_authenticated: return redirect(url_for('index'))
    return render_template('auth.html')

@app.route('/login', methods=['POST'])
def login_post():
    username = request.form.get('username')
    password = request.form.get('password')
    user = User.query.filter_by(username=username).first()
    if not user or not check_password_hash(user.password, password):
        flash('Неверные данные', 'error')
        return redirect(url_for('auth'))
    login_user(user)
    # При входе создаем новую сессию чата
    session['chat_id'] = str(uuid.uuid4())
    return redirect(url_for('index'))

@app.route('/register', methods=['POST'])
def register_post():
    username = request.form.get('username')
    password = request.form.get('password')
    if User.query.filter_by(username=username).first():
        flash('Занято!', 'error')
        return redirect(url_for('auth'))
    new_user = User(username=username, password=generate_password_hash(password))
    db.session.add(new_user)
    db.session.commit()
    flash('Готово', 'success')
    return redirect(url_for('auth'))

@app.route('/logout')
@login_required
def logout():
    session.pop('chat_id', None) # Удаляем сессию
    logout_user()
    return redirect(url_for('auth'))

@app.route('/api/chat', methods=['POST'])
@login_required
def chat_api():
    data = request.json
    prompt = data.get('prompt')
    model_key = data.get('model')
    deep_think = data.get('deep_think')
    uploaded_image = data.get('image')
    
    # Берем текущий ID чата из сессии
    current_sid = session.get('chat_id', str(uuid.uuid4()))

    ai_model = MODEL_MAPPING.get(model_key, "gpt-4o")
    is_gen_image = (model_key == 'dalle-3')

    allowed, msg = check_limits(current_user, is_gen_image)
    if not allowed: return jsonify({'error': msg})

    try:
        if is_gen_image:
            res = client.images.generate(model="dall-e-3", prompt=prompt, n=1, size="1024x1024")
            content = res.data[0].url
            current_user.images_count += 1
            current_user.last_image_time = time.time()
            
            # Сохраняем с session_id
            db.session.add(ChatHistory(user_id=current_user.id, session_id=current_sid, role='user', content=prompt))
            db.session.add(ChatHistory(user_id=current_user.id, session_id=current_sid, role='assistant', content=content, is_image=True))

        else:
            messages = []
            sys_prompt = "Ты AngerAI. Дерзкий и умный."
            if deep_think: sys_prompt += " Анализируй глубоко."
            messages.append({"role": "system", "content": sys_prompt})

            # ДОСТАЕМ ИСТОРИЮ ТОЛЬКО ЭТОГО ЧАТА (последние 10 сообщений)
            past_msgs = ChatHistory.query.filter_by(
                user_id=current_user.id, 
                session_id=current_sid # <--- Фильтр по сессии
            ).order_by(ChatHistory.timestamp.desc()).limit(10).all()
            
            past_msgs.reverse()

            for msg in past_msgs:
                if not msg.is_image:
                    messages.append({"role": msg.role, "content": msg.content})

            user_content = []
            if prompt: user_content.append({"type": "text", "text": prompt})
            if uploaded_image:
                user_content.append({"type": "image_url", "image_url": {"url": uploaded_image}})
                db.session.add(ChatHistory(user_id=current_user.id, session_id=current_sid, role='user', content=uploaded_image, is_image=True))
            else:
                db.session.add(ChatHistory(user_id=current_user.id, session_id=current_sid, role='user', content=prompt))

            messages.append({"role": "user", "content": user_content})
            
            comp = client.chat.completions.create(model=ai_model, messages=messages)
            content = comp.choices[0].message.content
            
            db.session.add(ChatHistory(user_id=current_user.id, session_id=current_sid, role='assistant', content=content))
        
        current_user.requests_count += 1
        db.session.commit()
        return jsonify({'response': content, 'is_image': is_gen_image})

    except Exception as e:
        return jsonify({'error': str(e)})

if __name__ == '__main__':
    app.run(debug=True, port=5000)
