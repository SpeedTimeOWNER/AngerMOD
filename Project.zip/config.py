import os

class Config:
    SECRET_KEY = 'SuperNonStop1-7569-0581-3073-7767-0697569-0581-30731-7569-0581-3073-7767-069' # Поменяй на что-то сложное
    SQLALCHEMY_DATABASE_URI = 'sqlite:///karma.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
