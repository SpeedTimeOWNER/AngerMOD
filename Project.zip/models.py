from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from datetime import datetime

db = SQLAlchemy()

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)
    
    # Лимиты
    requests_count = db.Column(db.Integer, default=0)
    last_request_date = db.Column(db.String(20), default=str(datetime.utcnow().date()))
    
    images_count = db.Column(db.Integer, default=0)
    last_image_time = db.Column(db.Float, default=0.0)

class ChatHistory(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    role = db.Column(db.String(20), nullable=False) # user или ai
    content = db.Column(db.Text, nullable=False)
    is_image = db.Column(db.Boolean, default=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
